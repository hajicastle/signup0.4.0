export const ACCESS_TOKEN = "access";
export const REFRESH_TOKEN = "refresh";

// browser에서 두 token에 접근하기 위해 사용하는 key (local storage)